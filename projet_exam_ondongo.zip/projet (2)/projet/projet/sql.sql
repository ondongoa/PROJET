-- Table for Domaine (DOMAINE)
CREATE TABLE DOMAINE (
    id_domaine INT PRIMARY KEY AUTO_INCREMENT,
    nom_domaine VARCHAR(255) NOT NULL,
    nom_producteur_domaine VARCHAR(100),
    prenom_producteur_domaine VARCHAR(100),
    lien_site_domaine VARCHAR(255)
);

-- Table for User (UTILISATEUR)
CREATE TABLE UTILISATEUR (
    pseudo_utilisateur VARCHAR(50) PRIMARY KEY,
    mdp_utilisateur VARCHAR(255) NOT NULL,
    nom_utilisateur VARCHAR(100) NOT NULL,
    prenom_utilisateur VARCHAR(100) NOT NULL,
    sexe_utilisateur CHAR(1),
    email_utilisateur VARCHAR(100) UNIQUE
);

-- Table for Cave (CAVE)
CREATE TABLE CAVE (
    id_cave INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL,
    pseudo_utilisateur VARCHAR(50),  -- Foreign key to link to the user
    FOREIGN KEY (pseudo_utilisateur) REFERENCES UTILISATEUR(pseudo_utilisateur)
);



-- Table for Shelf (ETAGERE)
CREATE TABLE ETAGERE (
    id_etagere INT PRIMARY KEY AUTO_INCREMENT,
    numero_etagere INT NOT NULL,
    nbre_emplacement INT NOT NULL,
    nbre_bouteilles INT NOT NULL,
    id_cave INT,  -- Foreign key to CAVE
    FOREIGN KEY (id_cave) REFERENCES CAVE(id_cave)
);







CREATE TABLE VIN (
    id_vin INT PRIMARY KEY AUTO_INCREMENT,
    nom_vin VARCHAR(255) NOT NULL,
    type_vin VARCHAR(50),
    annee_vin YEAR,
    note_globale_vin DECIMAL(3,2),  -- Global average rating (e.g., 4.25)
    prix_vin DECIMAL(8,2),
    id_cave INT,  -- Foreign key to link to the cave
    FOREIGN KEY (id_cave) REFERENCES CAVE(id_cave)
);


-- Table for Bottle (BOUTEILLE)
CREATE TABLE BOUTEILLE (
    id_bouteille INT PRIMARY KEY AUTO_INCREMENT,
    nom_emplacement_bouteille VARCHAR(100),
    quantite_bouteille INT, -- Add this line if it doesn't exist
    id_cave INT,  -- Ensure foreign key to CAVE
    id_vin INT,   -- Ensure foreign key to VIN
    FOREIGN KEY (id_cave) REFERENCES CAVE(id_cave),
    FOREIGN KEY (id_vin) REFERENCES VIN(id_vin)
);

-- Table for Entry (ENTREE)
CREATE TABLE ENTREE (
    id_entree INT PRIMARY KEY AUTO_INCREMENT,
    date_entree DATE NOT NULL,
    evenement_entree VARCHAR(255),
    lieu_achat_entree VARCHAR(255),
    quantite_entree INT NOT NULL,
    id_bouteille INT,  -- Foreign key to BOUTEILLE
    FOREIGN KEY (id_bouteille) REFERENCES BOUTEILLE(id_bouteille)
);

-- Table for Exit (SORTIE)
CREATE TABLE SORTIE (
    id_sortie INT PRIMARY KEY AUTO_INCREMENT,
    date_sortie DATE NOT NULL,
    evenement_sortie VARCHAR(255),
    quantite_sortie INT NOT NULL,
    note_archivage INT,  -- The note given when archiving the bottle
    id_bouteille INT,    -- Foreign key to BOUTEILLE
    FOREIGN KEY (id_bouteille) REFERENCES BOUTEILLE(id_bouteille)
);


CREATE TABLE COMMENTAIRE (
    id_commentaire INT PRIMARY KEY AUTO_INCREMENT,
    commentaire TEXT NOT NULL,
    date_commentaire TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    note_commentaire INT CHECK (note_commentaire BETWEEN 0 AND 5),  -- User rating between 0 and 5
    pseudo_utilisateur VARCHAR(50),  -- Foreign key to UTILISATEUR
    id_vin INT,  -- Foreign key to VIN
    FOREIGN KEY (pseudo_utilisateur) REFERENCES UTILISATEUR(pseudo_utilisateur),
    FOREIGN KEY (id_vin) REFERENCES VIN(id_vin)
);

